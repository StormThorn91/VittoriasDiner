package com.example.admin.order;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    EditText qchick, qfries, qnugget, qfish, qpasta, qsinigang;
    String chk1 = "", chk2 = "",chk3 = "",chk4 = "",chk5 = "",chk6 = "";

    Button btnorder;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        qchick = (EditText) findViewById(R.id.txtchick);
        qfries = (EditText) findViewById(R.id.txtfries);
        qnugget = (EditText) findViewById(R.id.txtnuggets);
        qfish = (EditText) findViewById(R.id.txtfish);
        qpasta = (EditText) findViewById(R.id.txtpasta);
        qsinigang = (EditText) findViewById(R.id.txtsinigang);

        btnorder = (Button) findViewById(R.id.btnorder);

    }

    public void onCheckMenu(View view){
        boolean check = ((CheckBox) view).isChecked();

        switch (view.getId()){
            case R.id.chkchick:
                if(check){
                    chk1 = "Chicken";
                    qchick.setEnabled(true);
                }
                else {
                    chk1 = "";
                    qchick.setEnabled(false);
                }

            case R.id.chkfries:
                if(check){
                    chk2 = "French Fries";
                    qfries.setEnabled(true);
                }
                else {
                    chk2 = "";
                    qfries.setEnabled(false);
                }

            case R.id.chknuggets:
                if(check){
                    chk3 = "Nuggets";
                    qnugget.setEnabled(true);
                }
                else {
                    chk3 = "";
                    qnugget.setEnabled(false);
                }

            case R.id.chkfish:
                if(check){
                    chk4 = "Fish";
                    qfish.setEnabled(true);
                }
                else {
                    chk4 = "";
                    qfish.setEnabled(false);
                }

            case R.id.chkpasta:
                if(check){
                    chk5 = "Pasta";
                    qpasta.setEnabled(true);
                }
                else {
                    chk5 = "";
                    qpasta.setEnabled(false);
                }

            case R.id.chksinigang:
                if(check){
                    chk6 = "Sinigang";
                    qsinigang.setEnabled(true);
                }
                else {
                    chk6 = "";
                    qsinigang.setEnabled(false);
                }
        }
    }


    public void Order(View view){

        double quanchick = Double.valueOf(qchick.getText().toString());
        double quanfries = Double.valueOf(qfries.getText().toString());
        double quannugget = Double.valueOf(qnugget.getText().toString());
        double quanfish = Double.valueOf(qfish.getText().toString());
        double quanpasta = Double.valueOf(qpasta.getText().toString());
        double quansinigang = Double.valueOf(qsinigang.getText().toString());


        double totalchick = quanchick * 65;
        double totalfries = quanfries * 55;
        double totalnugget = quannugget * 70;
        double totalfish = quanfish * 50;
        double totalpasta = quanpasta * 80;
        double totalsinigang =  quansinigang * 90;

        double totalall = totalchick + totalfries + totalnugget + totalfish + totalpasta + totalsinigang;

        StringBuilder output = new StringBuilder();

        output.append("Total Amount Ordered = " + totalall);
        Toast toast = Toast.makeText(this, output, Toast.LENGTH_SHORT);
        toast.show();

    }
}

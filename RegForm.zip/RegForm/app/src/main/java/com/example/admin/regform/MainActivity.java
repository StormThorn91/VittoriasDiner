package com.example.admin.regform;

import android.arch.lifecycle.AndroidViewModel;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    EditText txname, txadd, txnum, txemail;
    Button btnadd;
    ListView list;
    ArrayList<String> arrname = new ArrayList<String>();
    ArrayList<String> arradd = new ArrayList<String>();
    ArrayList<String> arrnum = new ArrayList<String>();
    ArrayList<String> arremail = new ArrayList<String>();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        list = (ListView) findViewById(R.id.listview);
        txname = (EditText) findViewById(R.id.txtname);
        txadd = (EditText) findViewById(R.id.txtaddress);
        txnum = (EditText) findViewById(R.id.txtnumber);
        txemail = (EditText) findViewById(R.id.txtemail);
        btnadd = (Button) findViewById(R.id.btnadd);
        btnadd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                    String name = txname.getText().toString();
                    String add = txadd.getText().toString();
                    String num = txnum.getText().toString();
                    String email = txemail.getText().toString();

                    if (arrname.contains(name)) {
                        Toast.makeText(getBaseContext(), "Name already created in the database", Toast.LENGTH_LONG).show();
                    } else if (arremail.contains(email)) {
                        Toast.makeText(getBaseContext(), "email already created in the database", Toast.LENGTH_LONG).show();
                    }else if (name == null || name.equals(" ") || add == null || add.equals(" ")|| num == null || num.equals(" ")|| email == null || email.equals(" ")) {
                        Toast.makeText(getBaseContext(), "Make sure any input field above is completed", Toast.LENGTH_LONG).show();
                    } else {
                        arrname.add(name);
                        arradd.add(add);
                        arrnum.add(num);
                        arremail.add(email);
                        ArrayAdapter<String> adapter = new ArrayAdapter<String>(MainActivity.this, android.R.layout.simple_list_item_1, arremail);

                        list.setAdapter(adapter);

                        ((EditText) findViewById(R.id.txtname)).setText("");
                        ((EditText) findViewById(R.id.txtnumber)).setText("");
                        ((EditText) findViewById(R.id.txtaddress)).setText("");
                        ((EditText) findViewById(R.id.txtemail)).setText("");
                    }
            }
        });
    }
}








